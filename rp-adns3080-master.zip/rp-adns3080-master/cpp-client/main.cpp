#include <stdio.h>
#include "camera.h"

int main(int argc, char const *argv[])
{
	/* code */
	setup();
	while(1)
	{
		loop();
	}
	return 0;
}